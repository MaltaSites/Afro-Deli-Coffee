from pathlib import Path
import zipfile, textwrap, os, json, math
base = Path('output/afro-deli-site')
assets = base/'assets'
assets.mkdir(parents=True, exist_ok=True)
html = '''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Afro Deli & Coffee in Gzira, Malta — authentic Ethiopian flavors, weekend Afrobeats, and delivery via Bolt Food and Wolt." />
  <title>Afro Deli & Coffee | Gzira, Malta</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/style.css" />
</head>
<body>
  <a class="skip-link" href="#main">Skip to content</a>
  <header class="site-header">
    <div class="container nav-wrap">
      <a class="brand" href="#home" aria-label="Afro Deli & Coffee home">
        <span class="brand-mark">AD</span>
        <span>
          <strong>Afro Deli & Coffee</strong>
          <small>Gzira, Malta</small>
        </span>
      </a>
      <button class="theme-toggle" type="button" aria-label="Toggle theme" aria-pressed="false">Theme</button>
      <nav class="site-nav" aria-label="Primary">
        <a href="#about">About</a>
        <a href="#menu">Menu</a>
        <a href="#events">Events</a>
        <a href="#contact">Contact</a>
      </nav>
    </div>
  </header>

  <main id="main">
    <section class="hero" id="home">
      <div class="container hero-grid">
        <div class="hero-copy">
          <p class="eyebrow">Authentic Ethiopian flavors in Gzira</p>
          <h1>Warm, urban dining with a soulful East African kitchen and weekend Afrobeats energy.</h1>
          <p class="lead">Afro Deli & Coffee serves traditional Ethiopian dishes, coffee, and a lively local atmosphere at 22 Triq Sir William Reid, Gzira.</p>
          <div class="cta-row">
            <a class="btn btn-primary" href="#menu">Explore the menu</a>
            <button class="btn btn-secondary" data-open-reservation>Reserve a table</button>
          </div>
          <div class="delivery-badges">
            <a class="delivery-logo bolt" href="https://food.bolt.eu/en-US/324-valletta/p/17426-afro-deli-&-coffee" target="_blank" rel="noopener noreferrer" aria-label="Order Afro Deli & Coffee on Bolt Food">Bolt Food</a>
            <a class="delivery-logo wolt" href="https://wolt.com/mt/mlt/malta/restaurant/afro-delli-coffee" target="_blank" rel="noopener noreferrer" aria-label="Order Afro Deli & Coffee on Wolt">Wolt</a>
          </div>
        </div>
        <div class="hero-card">
          <div class="hero-art" aria-hidden="true">
            <div class="art-shape art-a"></div>
            <div class="art-shape art-b"></div>
            <div class="art-shape art-c"></div>
          </div>
          <div class="hero-info">
            <p>Open daily <strong>11:00–23:00</strong></p>
            <p>Hours may run later on event nights.</p>
            <p>Delivery via Bolt Food and Wolt.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section about" id="about">
      <div class="container section-grid">
        <div>
          <p class="eyebrow">About</p>
          <h2>A neighborhood restaurant with genuine roots.</h2>
        </div>
        <div class="content-card">
          <p>Afro Deli & Coffee is positioned as a traditional Ethiopian restaurant in Gzira, with a menu centered on East African dishes and a welcoming dine-in experience.</p>
          <p>The public presence highlights authentic Ethiopian flavors, outdoor seating, and a social atmosphere that includes Afrobeats weekends and event-night energy.</p>
        </div>
      </div>
    </section>

    <section class="section menu" id="menu">
      <div class="container">
        <div class="section-head">
          <div>
            <p class="eyebrow">Menu</p>
            <h2>Curated signature dishes and the public menu structure.</h2>
          </div>
          <p class="section-note">The structure below is based on publicly visible Bolt Food and Wolt listings.</p>
        </div>
        <div class="signature-grid">
          <article class="menu-feature"><h3>All Veg</h3><p>A generous vegetarian platter with multiple stews and sides.</p></article>
          <article class="menu-feature"><h3>Doro Wot</h3><p>Traditional Ethiopian chicken stew, a central house-style favorite.</p></article>
          <article class="menu-feature"><h3>Key Wot</h3><p>Beef stew with deep spice and slow-cooked character.</p></article>
        </div>
        <div class="menu-columns">
          <div class="menu-panel">
            <h3>Publicly visible categories</h3>
            <ul class="menu-list">
              <li><strong>African Feast Combos</strong><span>Suggested meal deals on Wolt.</span></li>
              <li><strong>Traditional Ethiopian Dishes</strong><span>Main restaurant category.</span></li>
              <li><strong>Vegan dishes</strong><span>Stews and platters centered on legumes and vegetables.</span></li>
              <li><strong>Meat dishes</strong><span>Chicken, beef, lamb, and fish preparations.</span></li>
              <li><strong>Sambusas</strong><span>Publicly visible snack and starter category.</span></li>
              <li><strong>Injera-based plates</strong><span>Traditional teff flatbread service.</span></li>
            </ul>
          </div>
          <div class="menu-panel">
            <h3>Representative items seen publicly</h3>
            <ul class="menu-list compact">
              <li>Egusi Soup</li><li>Fufu</li><li>All Veg</li><li>Doro Wot</li><li>Key Wot (beef)</li><li>Vegan Sambusa (4 pieces)</li>
              <li>Tikil Gomen</li><li>Keysir Bendinich</li><li>Kik Alicha</li><li>Miser Wot</li><li>Shiro</li><li>Gomen</li>
              <li>Fassolia</li><li>All Veggies Injera</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section class="section events" id="events">
      <div class="container section-grid">
        <div>
          <p class="eyebrow">Events</p>
          <h2>Weekend Afrobeats, DJ nights, and a later rhythm after dark.</h2>
        </div>
        <div class="content-card">
          <p>Public posts highlight Afrobeats every weekend and a party-friendly atmosphere that supports community gatherings and live music.</p>
          <p>Plan for a flexible evening schedule: hours may run later on event nights, especially when the room is full and the music is going.</p>
        </div>
      </div>
    </section>

    <section class="section delivery" id="delivery">
      <div class="container">
        <div class="section-head">
          <div>
            <p class="eyebrow">Delivery</p>
            <h2>Order directly through your preferred platform.</h2>
          </div>
        </div>
        <div class="delivery-row">
          <a class="platform-card" href="https://food.bolt.eu/en-US/324-valletta/p/17426-afro-deli-&-coffee" target="_blank" rel="noopener noreferrer">Bolt Food</a>
          <a class="platform-card" href="https://wolt.com/mt/mlt/malta/restaurant/afro-delli-coffee" target="_blank" rel="noopener noreferrer">Wolt</a>
        </div>
      </div>
    </section>

    <section class="section contact" id="contact">
      <div class="container section-grid">
        <div>
          <p class="eyebrow">Contact</p>
          <h2>Visit Afro Deli & Coffee in Gzira.</h2>
        </div>
        <div class="content-card contact-card">
          <p><strong>Address:</strong> 22, Triq Sir William Reid, Gzira, GZR 1037 Malta</p>
          <p><strong>Hours:</strong> Daily 11:00–23:00</p>
          <p><strong>Phone:</strong> <a href="tel:+35677772988">+356 7777 2988</a></p>
          <p><strong>Email:</strong> <a href="mailto:afrodeliandcoffee@gmail.com">afrodeliandcoffee@gmail.com</a></p>
        </div>
      </div>
    </section>
  </main>

  <div class="mobile-bar" aria-label="Quick actions">
    <button class="mobile-action" data-open-reservation>Book</button>
    <a class="mobile-action" href="https://food.bolt.eu/en-US/324-valletta/p/17426-afro-deli-&-coffee" target="_blank" rel="noopener noreferrer">Bolt</a>
    <a class="mobile-action" href="https://wolt.com/mt/mlt/malta/restaurant/afro-delli-coffee" target="_blank" rel="noopener noreferrer">Wolt</a>
  </div>

  <div class="modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="reservation-title">
    <div class="modal-backdrop" data-close-modal></div>
    <div class="modal-panel">
      <button class="modal-close" type="button" data-close-modal aria-label="Close reservation form">×</button>
      <h2 id="reservation-title">Reserve a table</h2>
      <form id="reservation-form" class="reservation-form">
        <label>Full Name<input name="name" required></label>
        <div class="form-grid">
          <label>Date<input name="date" type="date" required></label>
          <label>Time<input name="time" type="time" required></label>
        </div>
        <div class="form-grid">
          <label>Guests<input name="guests" type="number" min="1" value="2" required></label>
          <label>Notes<textarea name="notes" rows="4" placeholder="Allergies, celebrations, seating preferences"></textarea></label>
        </div>
        <div class="modal-actions">
          <button class="btn btn-primary" type="submit" data-channel="whatsapp">Send via WhatsApp</button>
          <button class="btn btn-secondary" type="submit" data-channel="email">Send via Email</button>
        </div>
      </form>
    </div>
  </div>

  <script src="assets/script.js"></script>
</body>
</html>'''
css = ''':root{--bg:#f6efe6;--panel:#fff8f0;--text:#23160f;--muted:#6d5a4d;--line:#e1c8b3;--accent:#c46a3a;--accent2:#b58a2a;--dark:#1b120d;--shadow:0 18px 50px rgba(57,31,15,.12)}
:root[data-theme="dark"]{--bg:#120d0a;--panel:#1b1410;--text:#f7e9dc;--muted:#c8b3a4;--line:#3b2a20;--accent:#e08955;--accent2:#d1a141;--shadow:0 18px 50px rgba(0,0,0,.35)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,sans-serif;background:var(--bg);color:var(--text);line-height:1.6}a,button,input,textarea{font:inherit}a{color:inherit}.container{width:min(1120px,calc(100% - 32px));margin:0 auto}.skip-link{position:absolute;left:-999px;top:12px;background:var(--panel);padding:10px 14px;z-index:999}.skip-link:focus{left:12px}.site-header{position:sticky;top:0;z-index:50;background:color-mix(in srgb,var(--bg) 86%,transparent);backdrop-filter:blur(18px);border-bottom:1px solid var(--line)}.nav-wrap{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:14px 0}.brand{display:flex;gap:12px;align-items:center;text-decoration:none}.brand-mark,.platform-card,.delivery-logo,.mobile-action,.btn{border-radius:999px}.brand-mark{width:42px;height:42px;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;font-weight:700}.brand strong,.hero h1,.section h2,h3{font-family:"Cormorant Garamond",serif}.brand small{display:block;color:var(--muted)}.site-nav{display:flex;gap:18px}.site-nav a{text-decoration:none;color:var(--muted)}.theme-toggle,.btn,.modal-close{border:1px solid var(--line);background:var(--panel);color:var(--text)}.theme-toggle{padding:10px 14px}.hero{padding:54px 0 24px}.hero-grid,.section-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:28px;align-items:center}.eyebrow{letter-spacing:.12em;text-transform:uppercase;color:var(--accent);font-size:.8rem;font-weight:700}.hero h1{font-size:clamp(3rem,7vw,5.6rem);line-height:.94;margin:.2em 0 .2em}.lead,.section-note,.content-card p,.menu-feature p,.hero-info p{color:var(--muted)}.cta-row,.delivery-badges,.delivery-row,.modal-actions{display:flex;flex-wrap:wrap;gap:12px}.btn,.platform-card,.delivery-logo{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:0 18px;text-decoration:none;cursor:pointer}.btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;border:none}.hero-card,.content-card,.menu-panel,.menu-feature{background:var(--panel);border:1px solid var(--line);box-shadow:var(--shadow);border-radius:28px}.hero-card{padding:18px;display:grid;gap:16px}.hero-art{height:290px;border-radius:22px;background:radial-gradient(circle at 20% 20%,rgba(196,106,58,.38),transparent 30%),radial-gradient(circle at 80% 30%,rgba(181,138,42,.35),transparent 25%),linear-gradient(160deg,#3a2218,#7a3e24 60%,#d7b38a);position:relative;overflow:hidden}.art-shape{position:absolute;border-radius:24px;opacity:.9}.art-a{width:120px;height:170px;background:#f0c28b;left:18%;top:22%}.art-b{width:92px;height:92px;background:#2c1b14;right:18%;top:14%}.art-c{width:160px;height:70px;background:#f7ede2;right:10%;bottom:16%}.hero-info{display:grid;gap:6px}.section{padding:30px 0}.section-head{display:flex;justify-content:space-between;gap:18px;align-items:end;margin-bottom:18px}.signature-grid,.menu-columns{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.menu-panel,.menu-feature,.content-card{padding:22px}.menu-list{list-style:none;padding:0;margin:0;display:grid;gap:12px}.menu-list li{padding-bottom:12px;border-bottom:1px solid var(--line)}.menu-list li:last-child{border-bottom:none}.menu-list span{display:block;color:var(--muted);font-size:.95rem}.compact{grid-template-columns:repeat(2,1fr);display:grid}.delivery-logo,.platform-card{background:var(--panel);border:1px solid var(--line);min-width:160px}.bolt::before,.wolt::before{content:"";width:22px;height:22px;margin-right:10px;border-radius:50%}.bolt::before{background:linear-gradient(135deg,#111,#f4b400)}.wolt::before{background:linear-gradient(135deg,#05c, #7cf)}.contact-card a{color:var(--accent)}.mobile-bar{position:fixed;left:0;right:0;bottom:0;display:none;gap:10px;padding:10px;background:color-mix(in srgb,var(--bg) 86%,transparent);backdrop-filter:blur(18px);border-top:1px solid var(--line);z-index:60}.mobile-action{flex:1;text-align:center;padding:12px 10px;border:1px solid var(--line);background:var(--panel);text-decoration:none;color:var(--text)}.modal{position:fixed;inset:0;display:grid;place-items:center;z-index:80}.modal-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.55)}.modal-panel{position:relative;width:min(640px,calc(100% - 24px));background:var(--bg);border:1px solid var(--line);border-radius:28px;padding:22px;box-shadow:var(--shadow)}.modal-close{position:absolute;right:16px;top:16px;width:40px;height:40px}.reservation-form{display:grid;gap:14px}.reservation-form label{display:grid;gap:8px;font-weight:600}.reservation-form input,.reservation-form textarea{width:100%;padding:14px 16px;border-radius:16px;border:1px solid var(--line);background:var(--panel);color:var(--text)}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media (max-width:900px){.hero-grid,.section-grid,.signature-grid,.menu-columns,.form-grid{grid-template-columns:1fr}.site-nav{display:none}.mobile-bar{display:flex}.hero{padding-top:28px}.section-head{flex-direction:column;align-items:flex-start}}@media (max-width:640px){.container{width:min(1120px,calc(100% - 22px))}.hero h1{font-size:clamp(2.5rem,14vw,4rem)}.hero-art{height:220px}}'''
js = '''const root=document.documentElement;const toggle=document.querySelector('.theme-toggle');const modal=document.querySelector('.modal');const openBtns=document.querySelectorAll('[data-open-reservation]');const closeBtns=document.querySelectorAll('[data-close-modal]');const form=document.getElementById('reservation-form');const savedTheme=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';root.dataset.theme=savedTheme;toggle.setAttribute('aria-pressed',savedTheme==='dark');function setTheme(theme){root.dataset.theme=theme;toggle.setAttribute('aria-pressed',theme==='dark');toggle.textContent=theme==='dark'?'Light':'Dark'}setTheme(savedTheme);toggle.addEventListener('click',()=>setTheme(root.dataset.theme==='dark'?'light':'dark'));function openModal(){modal.hidden=false;modal.setAttribute('aria-hidden','false');modal.querySelector('input,button,textarea').focus()}function closeModal(){modal.hidden=true;modal.setAttribute('aria-hidden','true')}openBtns.forEach(b=>b.addEventListener('click',openModal));closeBtns.forEach(b=>b.addEventListener('click',closeModal));document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.hidden)closeModal()});form.addEventListener('submit',e=>{e.preventDefault();const data=Object.fromEntries(new FormData(form).entries());const message=`Reservation request for Afro Deli & Coffee%0AName: ${data.name}%0ADate: ${data.date}%0ATime: ${data.time}%0AGuests: ${data.guests}%0ANotes: ${data.notes||'None'}`;const mailto=`mailto:afrodeliandcoffee@gmail.com?subject=Reservation%20Request&body=${message}`;const whatsapp=`https://wa.me/35677772988?text=${message}`;if(e.submitter.dataset.channel==='whatsapp')window.open(whatsapp,'_blank','noopener,noreferrer');else window.open(mailto,'_blank','noopener,noreferrer');});'''
readme = '''# Afro Deli & Coffee Onepage

Static one-page website for GitHub Pages.

## Contents
- `index.html`
- `assets/style.css`
- `assets/script.js`

## Features
- Responsive one-page layout
- Light and dark theme toggle
- Reservation modal with WhatsApp and Email actions
- Delivery links to Bolt Food and Wolt
- Mobile sticky action bar

## Deployment
Upload the files to a GitHub Pages repository and serve from the root.
'''
(base/'index.html').write_text(html, encoding='utf-8')
(assets/'style.css').write_text(css, encoding='utf-8')
(assets/'script.js').write_text(js, encoding='utf-8')
(base/'README.md').write_text(readme, encoding='utf-8')
zip_path = Path('output/afro-deli-site.zip')
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in base.rglob('*'):
        z.write(p, p.relative_to(base.parent))
print(zip_path)
print(base)

# Afro Deli & Coffee Onepage

Static one-page website for GitHub Pages.

## Contents
- `index.html`
- `assets/style.css`
- `assets/script.js`

## Features
- Responsive one-page layout
- Light and dark theme toggle
- Reservation modal with WhatsApp and Email actions
- Delivery links to Bolt Food and Wolt
- Mobile sticky action bar

## Deployment
Upload the files to a GitHub Pages repository and serve from the root.
